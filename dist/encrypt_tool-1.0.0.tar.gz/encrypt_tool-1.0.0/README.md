# Encrypt Tool

A simple CLI tool for AES encryption and decryption using Python and OCB mode.